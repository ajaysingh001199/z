import 'rc-table/assets/index.css';
export type AlignType = 'left' | 'center' | 'right';
export { default as Table } from 'rc-table';
